public class Order
{
   private String customerName;
   private int customerNumber;
   private int quantityOrdered;
   private double unitPrice;
   public double totalPrice;
   
   // public Order(String name, int customerNumber, int quantity, double price, double totalPrice)
//    {
//       this.customerName = name;
//       this.customerNumber = customerNumber;
//       this.quantityOrdered = quantity;
//       this.unitPrice = price;
//       this.totalPrice = totalPrice;
//    }

   public void setCustomerName(String name)
   {
      this.customerName = name;
   }
   
   public void setCustomerNumber(int CustomerNumber)
   {
      this.customerNumber = customerNumber;
   }
   
   public void setQuantityOrdered(int quantity)
   {
      this.quantityOrdered = quantity;
   }
   
   public void setUnitPrice(double price)
   {
      this.unitPrice = price;
   }
   
   public String getcustomerName()
   {
      return customerName;
   }
   public int getcustomerNumber()
   {
      return customerNumber;
   }
   public int getQuantityOrdered()
   {
      return quantityOrdered;
   }
   public double getUnitPrice()
   {
      return unitPrice;
   }
   
   //Methods
   public double computePrice()
   {
      return this.totalPrice = this.quantityOrdered * this.unitPrice;
   }
   
   public void display()
   {
      System.out.println("Customer Name: " + this.customerName);
      System.out.println("Customer Number: " + this.customerNumber);
      System.out.println("Quantity Ordered: " + this.quantityOrdered);
      System.out.println("Unit Prize: " + this.unitPrice);
      System.out.println("Total Prize: " + this.computePrice());
   }
} 