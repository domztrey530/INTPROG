public class ShippedOrder extends Order
{
   private double shippingFee;
   private double handlingCharge;
   
   public ShippedOrder()
   {
      this.shippingFee = 100.00;
      this.handlingCharge = 4.00;
   }
   
   
   @Override
   public double computePrice()
   {
      return this.totalPrice = (this.getQuantityOrdered() * this.getUnitPrice()) + this.shippingFee + this.handlingCharge;
   }
}