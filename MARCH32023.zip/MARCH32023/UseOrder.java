import java.util.*;

public class UseOrder
{
   public static void main(String[] args)
   {
      String customerName;
      int quantity, customerNumber;
      double unitPrice;
      
      Order o = new ShippedOrder();
      Scanner sc = new Scanner(System.in);
      
      System.out.print("Enter name: ");
      customerName = sc.nextLine();
      o.setCustomerName(customerName);
      
      System.out.print("Enter customer #: ");
      customerNumber = sc.nextInt();
      o.setCustomerNumber(customerNumber);
      
      System.out.print("Enter quantity: ");
      quantity = sc.nextInt();
      o.setQuantityOrdered(quantity);
      
      System.out.print("Enter Price: ");
      unitPrice = sc.nextDouble();
      o.setUnitPrice(unitPrice);
      
      System.out.println(" ");
      o.computePrice();
      o.display();
      
   }
}