import java.io.*;
import java.util.*;

public class CreateItemFile 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        Map<String, String> items = new HashMap<>();

        // Prompt the user for item data
        while (true) 
        {
            System.out.print("Enter item number (or 'done' to quit): ");
            String itemNumber = sc.nextLine();

            if (itemNumber.equalsIgnoreCase("done")) 
            {
                break;
            }

            if (itemNumber.length() != 3) 
            {
                System.out.println("Error: Item number must be three digits.");
                continue;
            }

            if (items.containsKey(itemNumber)) 
            {
                System.out.println("Error: Item number already exists.");
                break;
            }
            else 
            {
                System.out.print("Enter item description (up to 20 characters): ");
                String itemDescription = sc.nextLine();

                if (itemDescription.trim().isEmpty() || itemDescription.length() > 20) 
                {
                    System.out.println("Error: Item description must not be empty and must be up to 20 characters.");
                    continue;
                }

                items.put(itemNumber, itemDescription);
            }
        }

        // Write item data to file
        try (PrintWriter writer = new PrintWriter(new File("items.txt"))) 
        {
            for (Map.Entry<String, String> item : items.entrySet()) 
            {
                writer.println(item.getKey() + " " + item.getValue());
            }
        } 
        catch (FileNotFoundException e) 
        {
            System.out.println("Error: Unable to create file.");
            return;
        }
        System.out.println("Item file created successfully.");
    }
}
