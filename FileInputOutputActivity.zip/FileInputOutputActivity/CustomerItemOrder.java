import java.io.*;
import java.util.*;

public class CustomerItemOrder 
{
    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);

        // Prompt the user for customer number and item ordered
        System.out.print("Enter customer number: ");
        String customerNumber = sc.nextLine();

        System.out.print("Enter item ordered: ");
        String itemOrdered = sc.nextLine();

        // Load customer and item data from files
        File customerFile = new File("customer.txt");
        File itemFile = new File("item.txt");

        String customerInfo = "";
        try (Scanner customerScanner = new Scanner(customerFile)) 
        {
            while (customerScanner.hasNextLine()) 
            {
                String line = customerScanner.nextLine();
                if (line.startsWith(customerNumber)) 
                {
                    customerInfo = line;
                    break;
                }
            }
        } 
        catch (FileNotFoundException e) 
        {
            System.out.println("Customer file not found.");
            return;
        }

        String itemInfo = "";
        try (Scanner itemScanner = new Scanner(itemFile)) 
        {
            while (itemScanner.hasNextLine()) 
            {
                String line = itemScanner.nextLine();
                if (line.startsWith(itemOrdered)) 
                {
                    itemInfo = line;
                    break;
                }
            }
        } 
        catch (FileNotFoundException e) 
        {
            System.out.println("Item file not found.");
            return;
        }

        // Display customer and item information or an error message
        if (customerInfo.isEmpty()) 
        {
            System.out.println("Error: Customer not found.");
        } 
        else if (itemInfo.isEmpty()) 
        {
            System.out.println("Error: Item not found.");
        } 
        else 
        {
            System.out.println("Customer information:");
            System.out.println(customerInfo);

            System.out.println("Item information:");
            System.out.println(itemInfo);
        }
    }
}
