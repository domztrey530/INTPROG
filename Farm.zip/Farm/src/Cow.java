public class Cow extends Animal{
  
  public Cow(String name, String breed, int age){
   super(name, breed, age);
  }
  
  public Cow(){}
  
  public String sound(){
   return ("Mooo mooo");
  }
  
  public String toString(){
	  return super.toString() +"Sound  : "+ sound();
  }
}