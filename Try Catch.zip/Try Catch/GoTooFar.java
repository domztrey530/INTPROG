import java.util.*;

public class GoTooFar
{
   public static void main(String[] args)
   {
      Scanner sc = new Scanner(System.in);
      int num[] = new int[5];
      try
      {
         for(int i=0; i<num.length+1; i++)
         {
            System.out.print("");
            num[i] = sc.nextInt();
         }
      }
      catch(ArrayIndexOutOfBoundsException exception)
      {
         System.out.println("Now you've gone too far");
      }   
   }
}