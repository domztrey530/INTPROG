import java.util.*;

public class NegativeArray
{
   public static void main(String[] args)
   {
     Scanner sc = new Scanner(System.in);
   
     try
     {
     
         System.out.println("Enter number: ");
         String size = sc.nextLine();
         int array[] = new int[Integer.parseInt(size)];
         System.out.println("Array is created successfully");
     }
     
     catch(NumberFormatException exception)
     {
         System.out.println("Array was not created");
     }
     catch(NegativeArraySizeException exception2)
     {
         System.out.println("Array was not created");
     }
   }
}