import java.util.*;

public class TryToParseString
{
   public static void main(String[] args)
   {
      Scanner sc = new Scanner(System.in);
      String str = sc.next();
      try
      {
        int a = Integer.parseInt(str); 
        System.out.println("Humana, the number is: " + a);
      }
      catch(NumberFormatException exception)
      {
         System.out.print("Invalid Input");
      }
   }
}