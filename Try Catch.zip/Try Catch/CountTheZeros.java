import java.util.*;

public class CountTheZeros
{
   public static void main(String[] args)
   {
      Scanner sc = new Scanner(System.in);
      System.out.print("Enter number: ");
      String num = sc.nextLine();
      
        for(int i=0;i<=num.length;i++)
        {
            countOfZeros+=countFactorsOf5(i);
        }
        return countOfZeros;
      }
}