/*
   Ouano, Matt Josel
   Dela Rita, Dominic Nicko
   Tecson, Akehide
*/
import java.io.*;
import java.util.*;

public class CreateItemFile {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Map<String, String> items = new HashMap<>();

        // Read existing item data from file
        try (Scanner fileScanner = new Scanner(new File("items.txt"))) {
            while (fileScanner.hasNextLine()) {
                String line = fileScanner.nextLine();
                String[] parts = line.split(" ");
                items.put(parts[0], parts[1]);
            }
        } catch (FileNotFoundException e) {
            System.out.println("Existing file not found.");
        }

        // Prompt the user for new item data
        while (true) {
            System.out.print("Enter item number (or 'done' to quit): ");
            String itemNumber = sc.nextLine();

            if (itemNumber.equalsIgnoreCase("done")) {
                break;
            }

            if (itemNumber.length() != 3) {
                System.out.println("Error: Item number must be three digits.");
                continue;
            }

            if (items.containsKey(itemNumber)) {
                System.out.println("Error: Item number already exists.");
                continue;
            }

            System.out.print("Enter item description (up to 20 characters): ");
            String itemDescription = sc.nextLine();

            if (itemDescription.trim().isEmpty() || itemDescription.length() > 20) {
                System.out.println("Error: Item description must not be empty and must be up to 20 characters.");
                continue;
            }

            items.put(itemNumber, itemDescription);
        }

        // Write updated item data to file
        try (PrintWriter writer = new PrintWriter(new FileWriter("items.txt"))) {
            for (Map.Entry<String, String> item : items.entrySet()) {
                writer.println(item.getKey() + " " + item.getValue());
            }
        } catch (IOException e) {
            System.out.println("Error: Unable to write to file.");
            e.printStackTrace();
        }

        System.out.println("Item file updated successfully.");
    }
}
