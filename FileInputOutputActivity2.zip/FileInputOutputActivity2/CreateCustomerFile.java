import java.io.*;
import java.util.*;

public class CreateCustomerFile 
{

    public static void main(String[] args) 
    {
        Scanner sc = new Scanner(System.in);
        Map<String, String[]> customers = new HashMap<>();

        // Open existing file or create new file for appending customer data
        File customerFile = new File("customers.txt");
        try (PrintWriter writer = new PrintWriter(new FileOutputStream(customerFile, true))) 
        {
            // do nothing if the file exists, otherwise create a new file
            if(!customerFile.exists()){
                customerFile.createNewFile();
            }
        } 
        catch (FileNotFoundException e) 
        {
            System.out.println("Error: Unable to create file.");
            return;
        } 
        catch (IOException e) 
        {
            System.out.println("Error: Unable to create file.");
            return;
        }

        // Prompt the user for customer data
        while (true) 
        {
            System.out.print("Enter customer ID (or 'done' to quit): ");
            String customerID = sc.nextLine();

            if (customerID.equalsIgnoreCase("done")) 
            {
                break;
            }

            if (customerID.length() != 3) 
            {
                System.out.println("Error: Customer ID must be three digits.");
                continue;
            }

            if (customers.containsKey(customerID)) 
            {
                System.out.println("Error: Customer ID already exists.");
                continue;
            }

            System.out.print("Enter customer last name (up to 6 characters): ");
            String customerLastName = sc.nextLine();
            if (customerLastName.length() > 6) 
            {
                customerLastName = customerLastName.substring(0, 6);
            } 
            else if (customerLastName.length() < 6) 
            {
                customerLastName = String.format("%-6s", customerLastName);
            }

            System.out.print("Enter customer ZIP code (5 digits): ");
            String customerZipCode = sc.nextLine();

            if (customerZipCode.length() != 5) 
            {
                System.out.println("Error: Customer ZIP code must be 5 digits.");
                continue;
            }

            customers.put(customerID, new String[] { customerLastName, customerZipCode });
        }

        // Write customer data to file
        try (PrintWriter writer = new PrintWriter(new FileOutputStream(customerFile, true))) 
        {
            for (Map.Entry<String, String[]> customer : customers.entrySet()) 
            {
                writer.println(customer.getKey() + " " + customer.getValue()[0] + " " + customer.getValue()[1]);
            }
            // Add new line character after each customer's data
            writer.println();
        } 
        catch (FileNotFoundException e) 
        {
            System.out.println("Error: Unable to write to file.");
            return;
        }
        System.out.println("Customer file created successfully.");
    }
}
