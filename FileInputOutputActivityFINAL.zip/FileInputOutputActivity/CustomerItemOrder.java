/*
   Dela Rita, Dominic Nicko B.
   BSIT3B
*/
import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class CustomerItemOrder {
    public static void main(String[] args) throws IOException {
        // read customer file
        File customerFile = new File("Customers.txt");
        if (!customerFile.exists()) {
            System.out.println("Error: Customer file does not exist.");
            return;
        }
        Scanner customerScanner = new Scanner(customerFile);

        // read item file
        File itemFile = new File("items.txt");
        if (!itemFile.exists()) {
            System.out.println("Error: Item file does not exist.");
            return;
        }
        Scanner itemScanner = new Scanner(itemFile);

        // accept user input
        Scanner userInputScanner = new Scanner(System.in);
        System.out.print("Enter customer number: ");
        String customerNumber = userInputScanner.nextLine();
        System.out.print("Enter item number: ");
        String itemNumber = userInputScanner.nextLine();

        // check for customer number in customer file
        String customerLine = null;
        while (customerScanner.hasNextLine()) {
            customerLine = customerScanner.nextLine();
            String[] customerParts = customerLine.split(" ");
            if (customerParts[0].equals(customerNumber)) {
                break;
            }
            customerLine = null;
        }
        if (customerLine == null) {
            System.out.println("Error: Customer number does not exist.");
            return;
        }

        // check for item number in item file
        String itemLine = null;
        while (itemScanner.hasNextLine()) {
            itemLine = itemScanner.nextLine();
            String[] itemParts = itemLine.split(" ");
            if (itemParts[0].equals(itemNumber)) {
                break;
            }
            itemLine = null;
        }
        if (itemLine == null) {
            System.out.println("Error: Item number does not exist.");
            return;
        }

        // display customer and item information
        String[] customerParts = customerLine.split(" ");
        String[] itemParts = itemLine.split(" ");
        System.out.println("#####################");
        System.out.println("Customer Information:");
        System.out.println("Customer Number: " + customerParts[0]);
        System.out.println("Last Name: " + customerParts[1]);
        System.out.println("Zip Code: " + customerParts[3]);
        System.out.println("#####################");
        System.out.println("Item Information:");
        System.out.println("Item Number: " + itemParts[0]);
        System.out.println("Description: " + itemParts[1]);
    }
}
