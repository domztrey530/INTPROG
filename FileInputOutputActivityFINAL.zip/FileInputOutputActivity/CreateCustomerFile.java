/*
   Dela Rita, Dominic Nicko B.
   BSIT3B
*/
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class CreateCustomerFile {
    public static void main(String[] args) throws IOException {
        // create file
        Path filePath = Paths.get("Z:\\PP209\\DELA RITA, DOMINIC NICKO B\\FileInputOutputActivity\\Customers.txt");
        Files.createDirectories(filePath.getParent());
        if (Files.notExists(filePath)) {
            Files.createFile(filePath);
            System.out.println("File created: " + filePath.getFileName());
        } else {
            System.out.println("File already exists.");
        }

        // open file for writing
        BufferedWriter writer = new BufferedWriter(new FileWriter(filePath.toFile()));

        // accept user input to populate file
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;
        while (!exit) {
            System.out.print("Enter customer ID number (3 digits): ");
            String id = scanner.nextLine();
            System.out.print("Enter customer last name (6 characters): ");
            String lastName = scanner.nextLine();
            System.out.print("Enter customer zip code (5 digits): ");
            String zipCode = scanner.nextLine();

            // check for duplicate ID numbers
            if (Files.lines(filePath).anyMatch(line -> line.startsWith(id))) {
                System.out.println("Error: ID number already exists.");
            } else {
                // force customer name to be 7 characters
                lastName = String.format("%-7s", lastName.substring(0, Math.min(lastName.length(), 6)));
                // write to file
                writer.write(id + " " + lastName + " " + zipCode + "\n");
                System.out.println("Record saved.");
            }

            // ask user if they want to exit or continue adding records
            System.out.print("Do you want to add another record? (Y/N): ");
            String choice = scanner.nextLine().toUpperCase();
            if (!choice.equals("Y")) {
                exit = true;
            }
        }

        // close file
        writer.close();
    }
}
