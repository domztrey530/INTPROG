/*
   Dela Rita, Dominic Nicko B.
   BSIT3B
*/
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class CreateItemFile {
    public static void main(String[] args) throws IOException {
        // create file
        File file = new File("items.txt");
        if (file.createNewFile()) {
            System.out.println("File created: " + file.getName());
        } else {
            System.out.println("File already exists.");
        }

        // open file for writing
        FileWriter writer = new FileWriter(file, true);

        // accept user input to populate file
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;
        while (!exit) {
            System.out.print("Enter item number (3 digits): ");
            String itemNumber = scanner.nextLine();
            System.out.print("Enter item description (up to 20 characters): ");
            String description = scanner.nextLine();

            // check for duplicate item numbers
            if (checkDuplicateItemNumber(file, itemNumber)) {
                System.out.println("Error: Item number already exists. Terminating program.");
                exit = true;
            } else {
                // write to file
                writer.write(itemNumber + " " + description + "\n");
                System.out.println("Record saved.");

                // ask user if they want to exit or continue adding records
                System.out.print("Do you want to add another record? (Y/N): ");
                String choice = scanner.nextLine().toUpperCase();
                if (!choice.equals("Y")) {
                    exit = true;
                }
            }
        }

        // close file
        writer.close();
    }

    public static boolean checkDuplicateItemNumber(File file, String itemNumber) throws IOException {
        Scanner scanner = new Scanner(file);
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            String[] parts = line.split(" ");
            if (parts[0].equals(itemNumber)) {
                return true;
            }
        }
        return false;
    }
}
