/*
   Dela Rita, Dominic Nicko B.
   BSIT 3-B
*/
public class MaoNiERunSaApp
{
   public static void main(String [] args)
   {
      new SetFrame();
   }
}